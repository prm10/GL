# Practical 5
Machine Learning, spring 2015

In this practical, we write and test our own layer.

## Setup
Setup will be the same as last time in practical 1. Please refer to the [practical 1 repository](https://github.com/oxford-cs-ml-2015/practical1), and run the script as instructed last time.

See the PDF for instructions on checking if `nngraph` was correctly installed, especially if you are using your own machine. If it is not installed, you must run:
```
luarocks install nngraph
```

## Practical
See the writeup PDF for instructions. There is only *one* handin item.


# See course page for practicals
<https://www.cs.ox.ac.uk/people/nando.defreitas/machinelearning/>

